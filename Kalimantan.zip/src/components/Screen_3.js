import React from 'react';
import Header_3 from './Screen_3/Header_3';
import Main from './Screen_3/Main';
function Screen_3() {
    return (
        <div className='Screen_3'>
            <Header_3/>
            <Main/>
        </div>
    )
}

export default Screen_3;
import Form from './Screen_6/Form';
import Footer from './Screen_6/Footer';

function Screen_6() {
    return(
        <div className='Screen_6'>
            <Form/>
            <Footer/>
        </div>
    )
}

export default Screen_6;
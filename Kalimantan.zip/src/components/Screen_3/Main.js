function Main() {
    return (
        <div className="main_main_3">
            <div className="steps_3">
                <div style={{fontSize: 35}}>Jungle Trip</div>
                <div style={{width: 400, fontSize: 18}}> The <b>expedition team</b> will travel to <b>the middle</b> of the <b>interior</b> of the Kalimantan forest.</div>
            </div>
        </div>
    )
}

export default Main;
function Header_3() {
    return(
        <div className="Head_3">
            <div style={{fontSize: 20}}>02 - Rare Experience Expedition</div>
            <div className="main_head_3">
                <div style={{fontSize: 40, fontWeight: 600, width: 500}}>We provide Expedition Rare Experience</div>
                <div style={{width: 500}}> <b>Explore</b> the jungle interior of Kalimantan to see and know more about <b>the beauty</b> of <b>flora and fauna.</b>Kalimantan to see and know more.</div>
            </div>
        </div>
    )
}
export default Header_3;
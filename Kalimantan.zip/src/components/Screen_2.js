import React from 'react';
import Main from './Screen_2/Main';
function Screen_2() {
    return (
        <div className='Screen_2'>
            <Main/>
        </div>
    )
}

export default Screen_2;
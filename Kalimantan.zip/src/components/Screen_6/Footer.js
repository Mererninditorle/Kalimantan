function Footer() {
    return(
        <div className="footer">
            <div>2022 © All Rights reserved.</div>
            <div className="soc_med_6">
                <img src="https://i.pinimg.com/originals/8b/57/e6/8b57e6b941286847f62c97388bcab2ae.png" height={33}/>
                <img src="https://cdn-icons-png.flaticon.com/512/25/25631.png" height={30}/>
                <img src="https://www.pikpng.com/pngl/b/422-4223736_robert-walters-20th-congress-spacesuit-twitter-icon-vector.png" height={30}/>
                <img src="https://www.pngkit.com/png/full/646-6466650_png-file-black-youtube-icon-png.png" height={30}/>
            </div>
        </div>
    )
}

export default Footer;
import React from 'react';
import Header_k from './Screen_1/Header_k';
import Main from './Screen_1/Main';

function Screen_1() {
    return (
        <div className='Screen_1'>
            <Header_k/>
            <Main/>
        </div>
    )
}

export default Screen_1
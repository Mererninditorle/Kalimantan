function Header_5() {
    return(
        <div className="head_5">
            <div style={{fontSize: 20}}>04 - Our Expertise Guides</div>
            <div style={{fontSize: 40, fontWeight: 600, width: 1000}}>Exploring the jungles of Kalimantan with guides and researchers accompanied by local residents</div>
            <div style={{width: 1000}}> <b>Explore</b> the jungle interior of Kalimantan to see and know more about <b>the beauty</b> of <b>flora and fauna.</b>Kalimantan to see and know more. <b>Explore</b> the jungle interior of Kalimantan to see and know more about <b>the beauty</b> of <b>flora and fauna.</b></div>
        </div>
    )
}

export default Header_5;
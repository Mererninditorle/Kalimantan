import Main from "./Screen_4/Main";

function Screen_4() {
    return(
        <div className="Screen_4">
            <Main/>
        </div>
    )
}

export default Screen_4;